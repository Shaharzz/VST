#include <stdio.h>

/* forward declarations of AST types */
typedef struct ASTNode ASTNode;
typedef struct ASTList ASTList;

extern ASTNode* ast_root;
extern int yyparse();
extern void print_ast(ASTNode* node, int indent);

int main() {
    if (yyparse() == 0) {
        printf("Parsed successfully.\n");
        printf("AST:\n");
        print_ast(ast_root, 0);
    } else {
        printf("Parsing failed.\n");
    }
    return 0;
}
